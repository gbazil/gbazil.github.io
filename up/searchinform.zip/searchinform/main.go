package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"strconv"
	"time"
)

// runtime app configuration
var config struct {
	BindAddr  string
	CacheTime int
	Providers []map[string]string
}

// cache item
type cache_item struct {
	country string
	ts      int64 // time stump
}

// resolved IP cache
var cache map[string]cache_item

// provider reponse counter
var rescounter map[string]int

// per minute counters cleaner
func minuteTicker() {
	t := time.NewTicker(time.Minute)
	for range t.C {
		// zeroing provider response counters
		for key, _ := range rescounter {
			rescounter[key] = 0
		}
	}
}

func handler(conn net.Conn) {
	defer conn.Close()

	ip, _, _ := net.SplitHostPort(conn.RemoteAddr().String())
	if cache[ip].ts > 0 && time.Now().Unix()-cache[ip].ts < int64(config.CacheTime) {
		// response from cache
		conn.Write([]byte(cache[ip].country))
		return
	}

	for _, provider := range config.Providers {
		limit, _ := strconv.Atoi(provider["ReqLimit"])
		if rescounter[provider["Url"]] > limit {
			continue
		}

		url := fmt.Sprintf(provider["Url"], ip) // value of key Url must have %s for ip
		resp, err := http.Get(url)
		if err != nil {
			continue
		}

		defer resp.Body.Close()

		body, err := ioutil.ReadAll(resp.Body)
		var j map[string]interface{}
		if err = json.Unmarshal(body, &j); err != nil {
			continue
		}

		// api difference compensation
		var country string
		if is, ok := j["country_name"]; ok {
			country = is.(string)
		} else if im, ok := j["country"].(map[string]interface{}); ok {
			country = im["name"].(string)
		}

		// cache and response
		if country != "" {
			rescounter[provider["Url"]]++
			cache[ip] = cache_item{country, time.Now().Unix()}

			conn.Write([]byte(country))
			break
		}
	}
}

func main() {
	cache = make(map[string]cache_item)
	rescounter = make(map[string]int)

	if buf, err := ioutil.ReadFile("config.json"); err != nil {
		panic(err)
	} else if err = json.Unmarshal(buf, &config); err != nil {
		panic(err)
	}

	go minuteTicker()

	l, err := net.Listen("tcp", config.BindAddr)
	if err != nil {
		panic(err)
	}

	defer l.Close()

	// main loop
	for {
		conn, err := l.Accept()
		if err != nil {
			continue
		}
		go handler(conn)
	}
}
